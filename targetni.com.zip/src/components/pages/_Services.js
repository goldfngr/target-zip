import React from 'react';
import '../../App.css';
import './Pages.css';

// export default function Services() {
//   return <h1 className='services'>SERVICES</h1>;

// }

function Services() {
  return (
      <div className="container">
        <h1>Services</h1>

          <h3>TNI has a broad range of service offerings for our Value Added Reseller partners/customers to utilize. But first we start with developing the initial solution development plan.   Then we work closely with our Value Added Reseller partners to develop a “Statement Of Work” SOW and then when the end user customer agrees to the plan we develop a timetable of events.  After completion of the project we review and survey the end customer and VAR partner to determine satisfaction level.</h3>

          <h3> Our Service Offerings include:</h3>

          <ul>
            <li>Large Scale WAN and LAN updating and deploying.</li>
            <li>Total Network development. </li>
            <li>Large scale computer deployment.</li>
            <li>Data center updates.</li>
            <li>Digital Signage- Installation, Development and Maintenance</li>
          </ul>
      </div>
  )
}

export default Services;
